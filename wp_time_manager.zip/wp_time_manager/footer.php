<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */
?>
			</div>
			<!-- /body_top -->
		</div>
		<!-- /body -->
		<!-- body_end -->
		<div id="body_end">&nbsp;</div>
		<!-- /body_end -->
		<!-- footer -->
		<div id="footer">
			<ul>
				<li class="first"><a href="<?php echo get_option('home'); ?>/">Home</a></li>
				<?php wp_list_pages('title_li=&sort_column=menu_order&depth=1') ?>
			</ul>
			<div id="footer_contact">
				<div class="item">
					<p>23-Ambush road</p>
					<p>0128thonhill</p>
					<p>CANADA</p>
				</div>
				<div class="item">
					<p><span>PH:</span></p>
					<p>012-2568-6897</p>
					<p>012-2568-6898</p>
				</div>
				<div class="item">
					<p><span>FAX:</span></p>
					<p>(012)-2568-6898</p>
					<p>(012)-2568-6898</p>
				</div>
			</div>
			<p class="copyrights">&copy; <a href="<?php echo get_option('home'); ?>/">time manager.</a> All rights reserved.</p>
			<p class="designed">Developed by: <a href="http://www.templateworld.com">Template World</a></p>
		</div>
		<!-- /footer -->
		<?php wp_footer(); ?>
	</div>
	<!-- /wrapper -->
</div>
<!-- /wrapper_top -->

</body>
</html>
