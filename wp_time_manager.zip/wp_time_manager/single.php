<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

get_header();
?>
	<!-- content -->
	<div id="content" class="narrowcolumn">

		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
			<!-- post -->
			<div <?php post_class('post') ?> id="post-<?php the_ID(); ?>">
				<h2 class="title"><?php the_title(); ?></h2>
				<div class="post_date">on <?php the_time('d F Y') ?></div>
				<div class="entry">
					<?php the_content('Read the rest of this entry &raquo;'); ?>
				</div>
			</div>
			<!-- /post -->
				<?php comments_template(); ?>
			<?php endwhile; ?>

	<?php else: ?>

		<p class="nopost">Sorry, no posts matched your criteria.</p>

<?php endif; ?>

	</div>
	<!-- /content -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>
