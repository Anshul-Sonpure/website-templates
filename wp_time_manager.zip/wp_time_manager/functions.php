<?php

$themename = "Theme Options";
$adminmenuname = "Theme Options";
$shortname = "thman";

$include_dir = 'includes';
$themeoptions_dir = $include_dir.'/theme-options';

// Functions
require_once($include_dir.'/fn-general.php');
require_once($themeoptions_dir.'/setup.php');

if ( function_exists('register_sidebar') )
    register_sidebar(array(
        'before_widget' => '<li id="%1$s" class="widget %2$s"><div class="widget_top"><div class="widget_end"><div class="widget_body">',
        'after_widget' => '</div></div></div></li>',
        'before_title' => '<h2 class="widgettitle">',
        'after_title' => '</h2>',
        'name' => 'Sidebar'
    ));

?>
