<?php
/**
 * @package WordPress
 * @subpackage magazine_obsession
 */

/**
 * Get Meta post/pages value
 * $type = string|int
 */
function thman_get_meta($var, $type = 'string', $count = 1)
{
	$value = stripslashes(get_option($var));
	
	if($type=='string')
	{
		return $value;
	}
	elseif($type=='int')
	{
		$value = intval($value);
		if( !is_int($value) || $value <=0 )
		{
			$value = $count;
		}
		
		return $value;
	}
	
	return NULL;
}

/**
 * Get custom field of the current page
 * $type = string|int
 */
function thman_getcustomfield($filedname, $page_current_id = NULL)
{
	if($page_current_id==NULL)
		$page_current_id = get_page_id();

	$value = get_post_meta($page_current_id, $filedname, true);

	return $value;
}

/* genereate menu */
function wp_list_pages2($args)
{
	$defaults = array(
		'depth' => 0, 'show_date' => '',
		'date_format' => get_option('date_format'),
		'child_of' => 0, 'exclude' => '',
		'title_li' => __('Pages'), 'echo' => 1,
		'authors' => '', 'sort_column' => 'menu_order, post_title',
		'link_before' => '', 'link_after' => ''
	);

	$r = wp_parse_args( $args, $defaults );
	extract( $r, EXTR_SKIP );

	$output = '';
	$current_page = 0;

	// sanitize, mostly to keep spaces out
	$r['exclude'] = preg_replace('/[^0-9,]/', '', $r['exclude']);

	// Allow plugins to filter an array of excluded pages
	$r['exclude'] = implode(',', apply_filters('wp_list_pages_excludes', explode(',', $r['exclude'])));

	// Query pages.
	$r['hierarchical'] = 0;
	$pages = get_pages($r);

	if ( !empty($pages) ) {
		if ( $r['title_li'] )
			$output .= '<li class="pagenav">' . $r['title_li'] . '<ul>';

		global $wp_query;
		if ( is_page() || $wp_query->is_posts_page )
			$current_page = $wp_query->get_queried_object_id();
		$output .= walk_page_tree($pages, $r['depth'], $current_page, $r);

		if ( $r['title_li'] )
			$output .= '</ul></li>';
	}

	$output = apply_filters('wp_list_pages', $output);

	if ( $r['echo'] )
		echo $output;
	else
		return $output;
}

/* get recent posts */	
function anwp_list_recent_posts($number = 10)
{

	$r = new WP_Query("showposts=$number&what_to_show=posts&nopaging=0&post_status=publish");
	if ($r->have_posts()) :
?>
		<ul>
			<?php $i=0;  while ($r->have_posts()) : $r->the_post(); $i++; ?>
			<li <?php if($i==$number) echo 'class="last"'; ?>><a href="<?php the_permalink() ?>"><?php if ( get_the_title() ) the_title(); else the_ID(); ?> </a></li>
			<?php endwhile; ?>
		</ul>
<?php
		wp_reset_query();  // Restore global post data stomped by the_post().
	endif;

}

/* get most commented posts */
function anwp_list_most_commented($no_posts = 5, $before = '<li>', $after = '</li>', $show_pass_post = false, $duration='')
{
    global $wpdb;
	
	$list_most_commented = wp_cache_get('list_most_commented');
	if ($list_most_commented === false) {
		$request = "SELECT ID, post_title, comment_count FROM $wpdb->posts";
		$request .= " WHERE post_status = 'publish'";
		if (!$show_pass_post) $request .= " AND post_password =''";
	
		if ($duration !="") $request .= " AND DATE_SUB(CURDATE(),INTERVAL ".$duration." DAY) < post_date ";
	
		$request .= " ORDER BY comment_count DESC LIMIT $no_posts";
		$posts = $wpdb->get_results($request);

		if ($posts) {
			foreach ($posts as $post) {
				$post_title = htmlspecialchars($post->post_title);
				$comment_count = $post->comment_count;
				$permalink = get_permalink($post->ID);
				$list_most_commented .= $before . '<a href="' . $permalink . '" title="' . $post_title.'">' . $post_title . '</a> (' . $comment_count.')' . $after;
			}
		} else {
			$list_most_commented .= $before . "None found" . $after;
		}
	
		wp_cache_set('list_most_commented', $list_most_commented);
	} 

    echo $list_most_commented;
}

/* Get featured posts */
function anwp_get_featured_post($max_posts=5, $offset=0)
{
	global $wpdb, $table_prefix;
	$table_name = $table_prefix."features";
	
	$sql = "SELECT * FROM $table_name ORDER BY date DESC LIMIT $offset, $max_posts";
	$posts = $wpdb->get_results($sql);

	$ar = array();
	if(count($posts)!=0)
	{
		foreach($posts as $post) {
			
			$ar[] = $post->id;
		}
	}
	else
	{
		$r = new WP_Query("showposts=".$max_posts."&offset=".$offset."&what_to_show=posts&nopaging=0&post_status=publish");
		if ($r->have_posts()) :
			while ($r->have_posts()) : $r->the_post();
				$ar[] = get_the_ID();
			endwhile;
			wp_reset_query();
		endif;
	}
	return $ar;
}


function thman_get_flickr_images($userID, $apiKey, $username, $count = 4, $rows = 2)
{
	if(!function_exists('curl_init'))
		return '';
		
	$photosAsXMLURL = "http://api.flickr.com/services/rest/?method=flickr.people.getPublicPhotos&api_key=".$apiKey."&user_id=".$userID;

	$curl = curl_init ($photosAsXMLURL);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	$photosAsXML = curl_exec ($curl);
	curl_close($curl); 

	preg_match_all("/id=\"(\d+)\"/", $photosAsXML, $ids);
	
	if(count($ids[1])!=0)
	{
		echo '<ul>';
		for($i=0; $i<count($ids[1]); $i++)
		{
			if($count==$i)
				break;
			$matchExpression = "/photo id=\"".$ids[1][$i]."\".*?secret=\"([a-z0-9]+)\".*?server=\"(\d+)\" farm=\"(\d+)\" title=\"([\w ]+)\"/";
			preg_match($matchExpression, $photosAsXML, $imageMatch);
		
			$imageURL = "http://farm".$imageMatch[3].".static.flickr.com/".$imageMatch[2]."/".$ids[1][$i]."_".$imageMatch[1]."_t.jpg";
		
			$linkURL = "http://www.flickr.com/photos/".$username."/".$ids[1][$i]; 
			
			$last = '';
			if(($i+1)%$rows==0)
			{
				$last = 'class="last"';
			}
			echo '<li '.$last.'><a href="'.$linkURL.'"><img src="'.$imageURL.'" alt="'.$imageMatch[4].'" /></a></li>';
		}
		echo '</ul>';
	}
}

/* Get Limited String */
function thman_get_limited_string($output, $max_char)
{
    $output = str_replace(']]>', ']]&gt;', $output);
    $output = strip_tags($output);

  	if ((strlen($output)>$max_char) && ($espacio = strpos($output, " ", $max_char )))
	{
        $output = substr($output, 0, $espacio).'...';
		return $output;
   }
   else
   {
      return $output;
   }
}

?>