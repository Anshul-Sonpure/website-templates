<?
/**
 * @package WordPress
 * @subpackage magazine_obsession
 */

/**
 * Show the General Settings for Admin oanel
 *
 * @since 2.7.0
 *
 */
function thman_general_settings()
{
    global $themename, $options, $shortname;

	$options = array (
				array(	"name" => "Main Settings",
						"type" => "heading"),
						
				array(	"name" => "Twitter ID",
						"desc" => "Enter twitter id.<br /><br />",
			    		"id" => $shortname."_twitter_id",
			    		"std" => "",
			    		"type" => "text"),
																														
		  );
	
	thman_add_admin('thman-settings.php');
}



?>