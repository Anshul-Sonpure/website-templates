<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

get_header(); ?>
	<!-- content -->
	<div id="content" class="narrowcolumn">

		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<!-- post -->
		<div class="post" id="post-<?php the_ID(); ?>">
			<!-- post_top -->
			<div class="post_top">
				<!-- post_end -->
				<div class="post_end">
					<h2 class="title"><?php the_title(); ?></h2>
					<div class="entry">
						<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
		
						<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
						<?php edit_post_link('Edit this entry.', '<br /><p>', '</p>'); ?>
		
					</div>
				</div>
				<!-- /post_end -->
			</div>
			<!-- /post_top -->
		</div>
		<!-- /post -->
		<?php endwhile; endif; ?>

	</div>
	<!-- /content -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>