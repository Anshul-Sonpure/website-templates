<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

get_header();
?>
	<!-- content -->
	<div id="content" class="narrowcolumn">

		<h2 class="nopost">Error 404 - Not Found</h2>


	</div>
	<!-- /content -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>