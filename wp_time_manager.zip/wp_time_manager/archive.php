<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

get_header();
?>
	<!-- content -->
	<div id="content" class="narrowcolumn">

		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
			<!-- post -->
			<div <?php post_class('post') ?> id="post-<?php the_ID(); ?>">
				<h2 class="title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
				<div class="post_date">on <?php the_time('d F Y') ?></div>
				<div class="entry">
					<?php the_content('Read the rest of this entry &raquo;'); ?>
				</div>
				<div class="info">
					<span class="post_author"><?php the_author() ?></span>
					<span class="post_comment"><?php comments_popup_link('Comments 0', 'Comments 1', 'Comments %'); ?></span>
					<span class="post_more"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><img src="<? bloginfo('template_url'); ?>/images/button_more.gif" alt="Permanent Link to <?php the_title_attribute(); ?>" /></a></span>
				</div>
			</div>
			<!-- /post -->
			<?php endwhile; ?>
		
		<?php 
		$next_page = get_next_posts_link('Previous'); 
		$prev_pages = get_previous_posts_link('Next');
		if(!empty($next_page) || !empty($prev_pages)) :
		?>
		<!-- navigation -->
		<div class="navigation">
			<?php if(!function_exists('wp_pagenavi')) : ?>
            <div class="alignleft"><?php echo $next_page; ?></div>
			<div class="alignright"><?php echo $prev_pages; ?></div>
            <?php else : wp_pagenavi(); endif; ?>
		</div>
		<!-- /navigation -->
		<?php endif; ?>
		
	<?php 
	
	else :

		if ( is_category() ) { // If this is a category archive
			printf("<h2 class='nopost'>Sorry, but there aren't any posts in the %s category yet.</h2>", single_cat_title('',false));
		} else if ( is_date() ) { // If this is a date archive
			echo("<h2 class='nopost'>Sorry, but there aren't any posts with this date.</h2>");
		} else if ( is_author() ) { // If this is a category archive
			$userdata = get_userdatabylogin(get_query_var('author_name'));
			printf("<h2 class='nopost'>Sorry, but there aren't any posts by %s yet.</h2>", $userdata->display_name);
		} else {
			echo("<h2 class='nopost'>No posts found.</h2>");
		}
		get_search_form();

	endif;
?>

	</div>
	<!-- /content -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>
