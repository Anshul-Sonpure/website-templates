<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */
 global $shortname;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<!--[if lte IE 7]><style media="screen,projection" type="text/css">@import "<?php bloginfo('template_url'); ?>/style-ie.css";</style><![endif]-->
<!--[if IE 6]>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/DD_belatedPNG_0.0.7a-min.js"></script>
<script type="text/javascript">
  DD_belatedPNG.fix('#logo a, #body, #body_end');
</script>
<![endif]-->
<!-- main menu -->
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jqueryslidemenu/jqueryslidemenu.js"></script>
<!-- /main menu -->
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>

<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<!-- wrapper_top -->
<div class="wrapper_top">
	<!-- wrapper -->
	<div class="wrapper">
		<?php if(is_home() || is_front_page()) : ?><div id="menu_shadow"><img src="<? bloginfo('template_url'); ?>/images/pic_menu_shadow.png" alt="" /></div><?php else : ?><div id="menu_shadow"><img src="<? bloginfo('template_url'); ?>/images/pic_menu_shadow2.png" alt="" /></div><?php endif; ?>
		<!-- header -->
		<div id="header">
			<!-- mainmenu -->
			<div id="mainmenu">
				<ul>
					<li class="first <? if(is_home()) echo 'current_page_item'; ?>"><a href="<?php echo get_option('home'); ?>/"><span>Home</span></a></li>
					<?php $exclude = thman_get_meta($shortname.'_exclude_page'); wp_list_pages2('title_li=&sort_column=menu_order&depth=0&link_before=<span>&link_after=</span>&exclude='.$exclude) ?>
				</ul>
			</div>
			<!-- /mainmenu -->
			<!-- sidebar_search -->
			<div id="sidebar_search">
				<form action="<?php bloginfo('url'); ?>/" method="get">
					<fieldset>
						<label for="main_search_val">Search</label>
						<input type="text" value="" name="s" id="main_search_val" />
						<input type="image" src="<?php bloginfo('template_url'); ?>/images/button_search.gif" alt="search" id="main_search_sub" />
					</fieldset>
				</form>
			</div>
			<!-- /sidebar_search -->
		</div>
		<!-- /header -->
		<!-- board -->
		<div id="board">
			<div id="logo"><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a></div>
			<p><?php bloginfo('description'); ?></p>
		</div>
		<!-- /board -->
		<!-- body -->
		<div id="body">
			<!-- body_top -->
			<div id="body_top">