<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */
 global $shortname;
?>
	<!-- sidebar -->
	<div id="sidebar">
		<!-- login_box -->
		<div id="login_box">
		<?php if(!is_user_logged_in()) : ?>
			<h2 class="title">members login</h2>
			<div id="login_body">
				<form action="<?php echo get_option('home'); ?>/wp-login.php" method="post">
					<fieldset>
						<p class="login_input"><input type="text" value="Your name" name="log" id="login_user" onclick="this.value=''" /></p>
						<p class="login_input"><input type="text" value="Password" name="pwd" id="login_pass" onclick="this.value=''" /></p>
						<p><input type="checkbox" name="rememberme" value="forever" id="login_rememberme" /><label for="login_rememberme">remember me</label><input type="image" src="<?php bloginfo('template_url'); ?>/images/button_login.png" alt="login" name="wp-submit" id="login_submit" /></p>
						<input type="hidden" name="redirect_to" value="<?php echo get_option('home'); ?>/" />
						<input type="hidden" name="testcookie" value="1" />
					</fieldset>
				</form>
			</div>
		<?php else : ?>
			<h2 class="title">members account</h2>
			<div id="login_body">
				<ul>
					<li><a href="<?php echo get_option('home'); ?>/wp-admin/">Account</a></li>
					<li><a href="<?php echo get_option('home'); ?>/wp-admin/edit.php">Posts</a></li>
					<li><a href="<?php echo get_option('home'); ?>/wp-admin/edit-pages.php">Pages</a></li>
					<li><?php wp_loginout(); ?></li>
				</ul>
			</div>
		<?php endif; ?>
		</div>
		<!-- /login_box -->
		<!-- sidebar_widgets -->
		<div class="sidebar_widgets">
			<ul>
				<?php 	/* Widgetized sidebar, if you have the plugin installed. */
						if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
	
				<li class="widget_categories">
					<div class="widget_top">
						<div class="widget_end">
							<div class="widget_body">
								<h2 class="widgettitle">Categories</h2>
								<ul>
								<?php wp_list_categories('show_count=0&title_li='); ?>
								</ul>
							</div>
						</div>
					</div>
				</li>	
				<li class="widget_archive">
					<div class="widget_top">
						<div class="widget_end">
							<div class="widget_body">
								<h2 class="widgettitle">Archives</h2>
								<ul>
								<?php wp_get_archives('type=monthly'); ?>
								</ul>
							</div>
						</div>
					</div>
				</li>
				<li class="widget_morelinks">
					<div class="widget_top">
						<div class="widget_end">
							<div class="widget_body">
								<h2 class="widgettitle">More Links</h2>
								<ul>
									<li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid XHTML</a></li>
									<li><a href="http://gmpg.org/xfn/">XFN</a></li>
									<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
								</ul>
							</div>
						</div>
					</div>
				</li>
				<li class="widget_links">
					<div class="widget_top">
						<div class="widget_end">
							<div class="widget_body">
								<h2 class="widgettitle">Partners Links</h2>
								<ul>
								<?php wp_list_bookmarks('title_li=&categorize=0'); ?>
								</ul>
							</div>
						</div>
					</div>
				</li>
				<li class="widget_meta">
					<div class="widget_top">
						<div class="widget_end">
							<div class="widget_body">
								<h2 class="widgettitle">Meta</h2>
								<ul>
									<?php wp_register(); ?>
									<li><?php wp_loginout(); ?></li>
									<li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a></li>
									<li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
									<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
									<?php wp_meta(); ?>
								</ul>
							</div>
						</div>
					</div>
				</li>		
				
				<?php endif; ?>
	
			</ul>
		</div>
		<!-- /sidebar_widgets -->
		<!-- sidebar_rss -->
		<div id="sidebar_rss">
			<ul>
				<li><a href="<?php bloginfo('rss2_url'); ?>">Posts</a></li>
				<li><a href="<?php bloginfo('comments_rss2_url'); ?>">Comments</a></li>
			</ul>
		</div>
		<!-- //sidebar_rss -->
	</div>
	<!-- /sidebar -->

