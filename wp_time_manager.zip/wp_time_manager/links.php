<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

/*
Template Name: Links
*/
?>

<?php get_header(); ?>

	<!-- content -->
	<div id="content" class="narrowcolumn">
		<!-- post -->
		<div class="post">
			<!-- post_top -->
			<div class="post_top">
				<!-- post_end -->
				<div class="post_end">
					<h2 class="title">Links:</h2>
					<div class="entry">
						<ul>
							<?php wp_list_bookmarks('categorize=0&title_li='); ?>
						</ul>
					</div>
				</div>
				<!-- /post_end -->
			</div>
			<!-- /post_top -->
		</div>
		<!-- /post -->
	</div>
	<!-- /content -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>
