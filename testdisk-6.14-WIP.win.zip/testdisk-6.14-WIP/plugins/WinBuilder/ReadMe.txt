TestDisk and PhotoRec v6.14 Plugin
===================================== 
Plugin by: Xtreme - Ahmed Hossam
Plugin for: Christophe GRENIER (www.cgsecurity.org)
Website: http://xtreme.boot-land.net
 -mirror: http://xtremee.orgfree.com
===================================== 

How to use the plugin ?
    * 1- Download WinBuilder v075 [beta_1]
	From here: http://winbuilder.net/download.php?list.12
    * 2- Copy TestDisk.script to the WinBuilder App project folder.
    * 3- Start your build and enjoy !

How to clean ?
     * Delete the BUILD folder
-------------------------------------------------------------------------
Copyright � Windows Xpire Tech Center.
--> It is published under GNU Public License 2 or later.
-------------------------------------------------------------------------
